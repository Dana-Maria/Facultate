window.onload = function() {
    /* Add click event for inputs */
    inputClick();

    /* Trigger click on a after clicking on li */
    liClick();

    /* Toggles the hidden lessons */
    toggleOnArrowClick();

    /* Toggle the hidden lessons for button click */
    goToTopic();
}
